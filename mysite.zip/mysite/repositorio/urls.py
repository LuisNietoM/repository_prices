from django.urls import path

from . import views

urlpatterns = [
    path("", views.ItemView.as_view(), name="index"),
    path("repositorio/<int:item_id>/", views.PrecioView.as_view(), name="precios"),
    path("repositorio/cotizacion/", views.CotizaView.as_view(), name="cotizacion"),
]
