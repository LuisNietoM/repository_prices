from django.contrib import admin
from .models import Item, Precio

admin.site.site_header = 'Panel de Administración'

# Register your models here.
admin.site.register(Item)
admin.site.register(Precio)

