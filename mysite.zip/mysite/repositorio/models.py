from django.db import models

class Item(models.Model):
    CLASE = {
        "MO": "MANO DE OBRA",
        "MT": "MATERIAL",
        "UC": "UNIDAD CONSTRUCTIVA",
    }
    item = models.CharField(max_length=100, unique=True)
    codigo_sap = models.CharField(max_length=50, null=True, blank=True) # unique=True
    descripcion = models.TextField(null=True, blank=True)
    unidad = models.CharField(max_length=50, null=True, blank=True)
    clase = models.CharField(max_length=2, choices=CLASE)
    subclase = models.CharField(max_length=200, null=True, blank=True)
    observacion = models.TextField(null=True, blank=True)
    url = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self) -> str:
        return self.item

class Precio(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE, related_name='precios') 
    precio_u = models.FloatField(default=0.0)
    fecha = models.DateField()
    proveedor = models.CharField(max_length=200, null=True, blank=True)
    def __str__(self):
        return f"{self.item}: ${self.precio_u}"

