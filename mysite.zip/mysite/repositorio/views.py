from .models import Item, Precio
from django.views import generic

class ItemView(generic.ListView):
    template_name = "item_list.html"
    model = Item

class PrecioView(generic.ListView):
    template_name = "precio_list.html"
    model = Precio

    def get_queryset(self):
        item_id = self.kwargs['item_id']
        queryset = Precio.objects.filter(item_id=item_id)\
                                 .select_related('item').all()
        return queryset

class CotizaView(generic.TemplateView):
    template_name = 'cotiza_list.html'

